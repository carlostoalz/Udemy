﻿namespace _5.DIP
{
    public class Email
    {
        public string Subject { get; set; }
        public string Content { get; set; }
        public void SendEmail()
        {
            //Send email
        }
    }
}