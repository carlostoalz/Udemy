﻿namespace _3.LSP
{
    public interface IAnimal
    {
        string Noise { get; set; }
        void MakeNoise();
    }
}