﻿namespace _3.LSP
{
   public class Dog : Animal
    {
    }
}
