﻿namespace _3.LSP
{
    public interface ICanFly : IAnimal
    {
        void Fly();
        
    }
}
