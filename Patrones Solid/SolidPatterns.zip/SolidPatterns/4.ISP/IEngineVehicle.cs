﻿namespace _4.ISP
{
    public interface IEngineVehicle
    {
        void startEngine();
        void stopEngine();
    }
}
