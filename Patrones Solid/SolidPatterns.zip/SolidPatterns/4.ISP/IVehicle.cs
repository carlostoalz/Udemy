﻿namespace _4.ISP
{
    public interface IVehicle
    {
        void Move();
        int GetNumberOfWheel();
       
    }
}

