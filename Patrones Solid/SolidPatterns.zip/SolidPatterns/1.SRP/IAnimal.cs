﻿namespace _1.SRP
{
    public interface IAnimal
    {
        string MakeNoise();
    }
}
