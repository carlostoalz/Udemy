﻿namespace _8.Reflexion
{
    public enum TypeOfPizza
    {
        Pepperoni,
        Neapolitan,
        California
    }
}
