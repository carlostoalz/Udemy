﻿namespace _8.Reflexion
{
    internal class NYCaliforniaPizza : Pizza
    {
        public NYCaliforniaPizza()
        {
            Name = "caifornia";
            Dough = "delgada";
            Sauce = "Salsa de tomates";
            Toppings.Add("Quesso mozarella");
        }
    }
}
