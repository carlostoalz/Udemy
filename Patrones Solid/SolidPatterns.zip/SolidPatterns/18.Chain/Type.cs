﻿namespace _18.Chain
{
    public enum Type
    {
        Basic,
        Medium,
        Premium
    }
}
