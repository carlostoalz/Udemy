﻿namespace _2.OCP
{
    public enum AnimalClass
    {
        Mamiferos,
        Peces,
        Aves,
        Reptiles
    }

    public enum AnimalOrder
    {
        Carnivoro,
        Herbivoro,
        Omnivoro
    }

}
